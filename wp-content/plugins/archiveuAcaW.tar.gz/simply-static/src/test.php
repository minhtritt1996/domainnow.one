<?php

						$attribute_value = '&#109;&#97;&#x69;&#x6c;&#116;&#111;&#x3a;&#x69;&#110;&#102;&#x6f;&#x40;&#112;&#97;&#x72;&#x61;&#103;&#111;&#x6e;&#x61;&#115;&#105;&#x61;&#x2e;&#104;&#107;';

                                                $decodeUrl = html_entity_decode($attribute_value);
echo $decodeUrl."\n";
//						echo "Decodeurl :".$decodeUrl;

                                                if(preg_match('/mailto/i', $decodeUrl))
						echo "success";
						else 
						echo "failed";

?>
