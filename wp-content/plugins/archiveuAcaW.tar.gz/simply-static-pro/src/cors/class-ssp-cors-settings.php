<?php

namespace simply_static_pro;

use Simply_Static;

/**
 * Class to handle settings for cors.
 */
class Cors_Settings {
	/**
	 * Contains instance or null
	 *
	 * @var object|null
	 */
	private static $instance = null;

	/**
	 * Returns instance of Cors_Settings.
	 *
	 * @return object
	 */
	public static function get_instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor for Cors_Settings.
	 */
	public function __construct() {
		add_action( 'simply_static_settings_view_tab', array( $this, 'output_settings_tab' ), 60 );
		add_action( 'simply_static_settings_view_form', array( $this, 'output_settings_form' ), 60 );
		add_filter( 'simply_static_options', array( $this, 'add_options' ) );
		add_filter( 'allowed_http_origins', array( $this, 'add_allowed_origins' ) );
		add_filter( 'wp_headers', array( $this, 'send_cors_headers' ), 11, 1 );
		add_action( 'init', array( $this, 'handle_cors_on_init' ) );
	}

	/**
	 * Output a new settings tab in Simply Static Settings.
	 *
	 * @return void
	 */
	public function output_settings_tab() {
		?>
		<a class='nav-tab' id='cors-tab' href='#tab-cors'><?php esc_html_e( 'CORS', 'simply-static-pro' ); ?></a>
		<?php
	}

	/**
	 * Output content for new settings tab in Simply Static Settings.
	 *
	 * @return void
	 */
	public function output_settings_form() {
		$options = get_option( 'simply-static' );

		// buffer output.
		ob_start();
		include( SIMPLY_STATIC_PRO_PATH . '/src/cors/views/cors.php' );
		$settings = ob_get_contents();
		ob_end_clean();

		// Replacing placeholders with values from options.
		if ( ! empty( $options['fix-cors'] ) ) {
			if ( 'allowed_http_origins' === $options['fix-cors'] ) {
				$select_options = '<option selected value="allowed_http_origins">allowed_http_origins</option><option value="wp_headers">wp_headers</option>';
			} else {
				$select_options = '<option selected value="wp_headers">wp_headers</option><option value="allowed_http_origins">allowed_http_origins</option>';
			}
			$settings = str_replace( '[FIX_CORS]', $select_options, $settings );
		} else {
			$select_options = '<option value="allowed_http_origins">allowed_http_origins</option><option value="wp_headers">wp_headers</option>';
			$settings = str_replace( '[FIX_CORS]', $select_options, $settings );
		}

		if ( ! empty( $options['static-url'] ) ) {
			$settings = str_replace( '[STATIC_URL]', $options['static-url'], $settings );
		} else {
			// Check if Search URL is set.
			if ( ! empty( $options['static-search-url'] ) ) {
				$settings = str_replace( '[STATIC_URL]', $options['static-search-url'], $settings );
			} else {
				$settings = str_replace( '[STATIC_URL]', '', $settings );
			}
		}

		echo $settings;
	}

	/**
	 * Filter the Simply Static options and add pro options.
	 *
	 * @param array $options array of options.
	 * @return array
	 */
	public function add_options( $options ) {
		$ss = Simply_Static\Plugin::instance();

		$options['fix-cors']   = $ss->fetch_post_value( 'fix-cors' );
		$options['static-url'] = $ss->fetch_post_value( 'static-url' );

		return $options;
	}

	/**
	 * Add static URL to allowed origins.
	 *
	 * @param  array $origins list of allowed origins.
	 * @return array
	 */
	public function add_allowed_origins( $origins ) {
		$options    = get_option( 'simply-static' );
		$static_url = '';

		if ( ! empty( $options['static-url'] ) ) {
			$static_url = $options['static-url'];
		} elseif ( ! empty( $options['static-search-url'] ) ) {
			$static_url = $options['static-search-url'];
		}

		if ( ! empty( $static_url ) ) {
			if ( 'allowed_http_origins' === $options['fix-cors'] ) {
				$origins[] = $options['static-url'];
			}
		}
		return $origins;
	}

	/**
	 * Send CORS via wp_header.
	 *
	 * @param  array $headers current headers.
	 * @return array
	 */
	public function send_cors_headers( $headers ) {
		$options    = get_option( 'simply-static' );
		$static_url = '';

		if ( ! empty( $options['static-url'] ) ) {
			$static_url = $options['static-url'];
		} elseif ( ! empty( $options['static-search-url'] ) ) {
			$static_url = $options['static-search-url'];
		}

		if ( ! empty( $static_url ) ) {
			if ( 'wp_headers' === $options['fix-cors'] ) {
				$allowed_domains = array( $static_url );

				if ( isset( $_SERVER['HTTP_ORIGIN'] ) ) {
					if ( ! in_array( $_SERVER['HTTP_ORIGIN'], $allowed_domains ) ) {
						return $headers;
					}
					$headers['Access-Control-Allow-Origin'] = $_SERVER[ 'HTTP_ORIGIN' ];
				}
			}
		}
		return $headers;
	}

	/**
	 * Handle CORS on init.
	 *
	 * @return void
	 */
	public function handle_cors_on_init() {
		$options    = get_option( 'simply-static' );
		$origin     = get_http_origin();
		$static_url = '';

		if ( ! empty( $options['static-url'] ) ) {
			$static_url = $options['static-url'];
		} elseif ( ! empty( $options['static-search-url'] ) ) {
			$static_url = $options['static-search-url'];
		}

		if ( ! empty( $static_url ) ) {
			if ( $origin === $static_url ) {
				header( 'Access-Control-Allow-Origin: ' . $static_url );
				header( 'Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE' );
				header( 'Access-Control-Allow-Credentials: true' );
				header( 'Access-Control-Allow-Headers: Origin, X-Requested-With, X-WP-Nonce, Content-Type, Accept, Authorization ' );

				if ( 'OPTIONS' == $_SERVER['REQUEST_METHOD'] ) {
					status_header( 200 );
					exit();
				}
			}
		}
	}
}
