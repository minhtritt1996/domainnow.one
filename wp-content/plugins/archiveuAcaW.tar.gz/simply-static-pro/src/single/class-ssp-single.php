<?php

namespace simply_static_pro;

use Simply_Static;

/**
 * Class to handle settings for single.
 */
class Single {
	/**
	 * Contains instance or null
	 *
	 * @var object|null
	 */
	private static $instance = null;

	/**
	 * Returns instance of Single.
	 *
	 * @return object
	 */
	public static function get_instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor for Single.
	 */
	public function __construct() {
		add_filter( 'ss_static_pages', array( $this, 'filter_static_pages' ), 10, 2 );
		add_filter( 'ss_remaining_pages', array( $this, 'filter_remaining_pages' ), 10, 2 );
		add_filter( 'ss_total_pages', array( $this, 'filter_total_pages' ) );
		add_filter( 'ss_total_pages_log', array( $this, 'filter_total_pages_log' ) );
		add_action( 'wp_ajax_apply_single', array( $this, 'apply_single' ) );
		add_action( 'wp_ajax_nopriv_apply_single', array( $this, 'apply_single' ) );
		add_action( 'wp_ajax_apply_single_render', array( $this, 'apply_single_render' ) );
		add_action( 'wp_ajax_nopriv_apply_single_render', array( $this, 'apply_single_render' ) );
		add_action( 'ss_after_cleanup', array( $this, 'clear_single' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'add_admin_scripts' ) );
		add_action( 'ssp_comment_added', array( $this, 'export_single' ) );
	}

	/**
	 * Enqueue admin scripts.
	 */
	public function add_admin_scripts() {
		wp_enqueue_script( 'ssp-single-admin', SIMPLY_STATIC_PRO_URL . '/assets/ssp-single-admin.js', array( 'jquery' ), '1.0.2', true );

		wp_localize_script(
			'ssp-single-admin',
			'ssps_ajax',
			array(
				'ajax_url'         => admin_url() . 'admin-ajax.php',
				'run_single_nonce' => wp_create_nonce( 'ssp-run-single' ),
				'redirect_url'     => admin_url() . 'admin.php?page=simply-static',
			)
		);
	}

	/**
	 * Generate single for static export.
	 *
	 * @return void
	 */
	public function apply_single() {
		// print_r($_REQUEST);
		// exit();
			// check nonce.
			if ( ! wp_verify_nonce( $_POST['nonce'], 'ssp-run-single' ) ) {
				$response = array( 'message' => 'Security check failed.' );
				print wp_json_encode( $response );
				exit;
			}
	
			$single_id = intval( $_POST['single_id'] );
	
			// Update option for using a single post.
			update_option( 'simply-static-use-single', $single_id );
	
			// Add URLs.
			self::add_url( $single_id );
	
			do_action( 'ssp_before_run_single' );
	
			// Start static export.
			$ss = Simply_Static\Plugin::instance();
			$ss->run_static_export();
	
			// Exit now.
			$response = array( 'success' => true );
			print wp_json_encode( $response );
			shell_exec('/bin/bash /var/www/static_vffte_usr76/data/www/static.vfftech.vn/vfftech.vn/transfer_file_to_public_server.sh');
			exit;
		}
		public function apply_single_render() {
		// print_r($_REQUEST);
		// exit();
			// check nonce.
			if ( ! wp_verify_nonce( $_POST['nonce'], 'ssp-run-single' ) ) {
				$response = array( 'message' => 'Security check failed.' );
				print wp_json_encode( $response );
				exit;
			}
	
			$single_id = intval( $_POST['single_id'] );
	
			// Update option for using a single post.
			update_option( 'simply-static-use-single', $single_id );
	
			// Add URLs.
			self::add_url( $single_id );
	
			do_action( 'ssp_before_run_single' );
	
			// Start static export.
			$ss = Simply_Static\Plugin::instance();
			$ss->run_static_export();
	
			// Exit now.
			$response = array( 'successccccc' => true );
			print wp_json_encode( $response );
			shell_exec('/bin/bash /var/www/static_vffte_usr76/data/www/static.vfftech.vn/vfftech.vn/copy_file_to_html_folder.sh');
			shell_exec('/bin/bash /var/www/static_vffte_usr76/data/www/static.vfftech.vn/vfftech.vn/transfer_file_to_public_server.sh');
			exit;
		}

	/**
	 * Clear selected single after export.
	 *
	 * @return void
	 */
	public function clear_single() {
		delete_option( 'simply-static-use-single' );
	}

	/**
	 * Filter additional urls
	 *
	 * @param  int $single_id current single id.
	 * @return void
	 */
	public static function add_url( $single_id ) {
		Simply_Static\Page::query()->delete_all();

		$url = get_permalink( $single_id );

		if ( Simply_Static\Util::is_local_url( $url ) ) {
			$static_page          = Simply_Static\Page::query()->find_or_initialize_by( 'url', $url );
			$static_page->post_id = $single_id;
			$static_page->save();
		}
	}


	/**
	 * Filter static pages.
	 *
	 * @param  array $results results from database.
	 * @param  array $archive_start_time timestamp.
	 * @return array
	 */
	public function filter_static_pages( $results, $archive_start_time ) {
		$batch_size = apply_filters( 'simply_static_fetch_urls_batch_size', 10 );
		$use_single = get_option( 'simply-static-use-single' );

		if ( empty( $use_single ) ) {
			return $results;
		}

		$post_id = intval( $use_single );

		return Simply_Static\Page::query()
		->where( 'last_checked_at < ? AND post_id = ?', $archive_start_time, $post_id )
		->limit( $batch_size )
		->find();
	}

	/**
	 * Filter remaining pages.
	 *
	 * @param  array $results results from database.
	 * @param  array $archive_start_time timestamp.
	 * @return array
	 */
	public function filter_remaining_pages( $results, $archive_start_time ) {
		$use_single = get_option( 'simply-static-use-single' );

		if ( empty( $use_single ) ) {
			return $results;
		}

		$post_id = intval( $use_single );

		return Simply_Static\Page::query()
		->where( 'last_checked_at < ? AND post_id = ?', $archive_start_time, $post_id )
		->count();
	}

	/**
	 * Filter total pages.
	 *
	 * @param  array $results results from database.
	 * @return array
	 */
	public function filter_total_pages( $results ) {
		$use_single = get_option( 'simply-static-use-single' );

		if ( empty( $use_single ) ) {
			return $results;
		}

		$post_id = intval( $use_single );

		return Simply_Static\Page::query()
		->where( 'post_id = ?', $post_id )
		->count();
	}

	/**
	 * Filter total pages for log.
	 *
	 * @param  array $results results from database.
	 * @return array
	 */
	public function filter_total_pages_log( $results ) {
		$per_page     = $_POST['per_page'];
		$current_page = $_POST['page'];
		$offset       = ( intval( $current_page ) - 1 ) * intval( $per_page );
		$use_single   = get_option( 'simply-static-use-single' );

		if ( empty( $use_single ) ) {
			return $results;
		}

		$post_id = intval( $use_single );

		return Simply_Static\Page::query()
			->where( 'post_id = ?', $post_id )
			->limit( $per_page )
			->offset( $offset )
			->order( 'http_status_code' )
			->find();
	}

	/**
	 * Export single if comment was added.
	 *
	 * @param  int $post_id given post id.
	 * @return void
	 */
	public function export_single( $post_id ) {
		// Update option for using single.
		$options               = get_option( 'simply-static' );
		$options['use-single'] = $post_id;

		update_option( 'simply-static', $options );

		// Add URLs.
		self::add_url( $post_id );

		do_action( 'ssp_before_run_single' );

		// Schedule export.
		wp_schedule_single_event( time(), 'simply_static_site_export_cron' );
	}
}
