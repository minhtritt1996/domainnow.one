<?php

namespace simply_static_pro;

use Simply_Static;

/**
 * Class to handle settings for deployment.
 */
class Search_Settings {
	/**
	 * Contains instance or null
	 *
	 * @var object|null
	 */
	private static $instance = null;

	/**
	 * Returns instance of Search_Settings.
	 *
	 * @return object
	 */
	public static function get_instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor for Search_Settings.
	 */
	public function __construct() {
		add_action( 'simply_static_settings_view_tab', array( $this, 'output_settings_tab' ), 30 );
		add_action( 'simply_static_settings_view_form', array( $this, 'output_settings_form' ), 30 );
		add_filter( 'simply_static_options', array( $this, 'add_options' ) );
		add_shortcode( 'ssp-search', array( $this, 'render_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'add_shortcode_scripts' ) );
		add_filter( 'simply_static_class_name', array( $this, 'check_class_name' ), 20, 2 );
		add_action( 'admin_enqueue_scripts', array( $this, 'add_admin_scripts' ) );
		add_action( 'wp_ajax_create_search_index', array( $this, 'create_search_index' ) );
		add_action( 'ssp_search_index_cron', array( $this, 'index' ) );
	}

	/**
	 * Output a new settings tab in Simply Static Settings.
	 *
	 * @return void
	 */
	public function output_settings_tab() {
		?>
		<a class='nav-tab' id='search-tab' href='#tab-search'><?php esc_html_e( 'Search', 'simply-static-pro' ); ?></a>
		<?php
	}

	/**
	 * Output content for new settings tab in Simply Static Settings.
	 *
	 * @return void
	 */
	public function output_settings_form() {
		$options = get_option( 'simply-static' );

		// buffer output.
		ob_start();
		include( SIMPLY_STATIC_PRO_PATH . '/src/search/views/search.php' );
		$settings = ob_get_contents();
		ob_end_clean();

		if ( ! empty( $options['static-search-url'] ) ) {
			$settings = str_replace( '[CREATE_INDEX]', '<a class="button button-secondary" name="create-index" id="create-index">' . esc_html__( 'Create index', 'simply-static-pro' ) . '</a>', $settings );
			$settings = str_replace( '[STATIC_URL]', $options['static-search-url'], $settings );
		} else {
			// Check if CORS URL is set.
			if ( ! empty( $options['static-url'] ) ) {
				$settings = str_replace( '[CREATE_INDEX]', '<a class="button button-secondary" name="create-index" id="create-index">' . esc_html__( 'Create index', 'simply-static-pro' ) . '</a>', $settings );
				$settings = str_replace( '[STATIC_URL]', $options['static-url'], $settings );
			} else {
				$settings = str_replace( '[STATIC_URL]', '', $settings );
				$settings = str_replace( '[CREATE_INDEX]', '', $settings );
			}
		}

		echo $settings;
	}

	/**
	 * Enqueue admin scripts.
	 */
	public function add_admin_scripts() {
		wp_enqueue_script( 'ssp-search-admin', SIMPLY_STATIC_PRO_URL . '/assets/ssp-search-admin.js', array( 'jquery' ), '1.0.2', true );

		wp_localize_script(
			'ssp-search-admin',
			'search_config',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'ssp-search-config' ),
			)
		);
	}

	/**
	 * Render search box shortcode.
	 *
	 * @return string
	 */
	public function render_shortcode() {
		ob_start();
		?>
		<div class="ssp-search">
			<form class="search-form">
				<div class="form-row">
				<div class="search-input-container">
					<input class="search-input" name="search-input" placeholder="<?php esc_html_e( 'Search', 'simply-static-pro' ); ?>" autocomplete="off">
					<div class="search-auto-complete"></div>
				</div>
				<button type="submit" class="search-submit">
					<svg viewBox="0 0 24 24">
					<path d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z" />
					</svg>
				</button>
				</div>
			</form>
			<div class="result"></div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Enqueue scripts for shortcode.
	 *
	 * @return void
	 */
	public function add_shortcode_scripts() {
		global $post;
		if ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'ssp-search') ) {
			wp_enqueue_style( 'ssp-search', SIMPLY_STATIC_PRO_URL . '/assets/ssp-search.css', array(), '1.0.2', 'all' );
			wp_enqueue_script( 'ssp-fuse', SIMPLY_STATIC_PRO_URL . '/assets/fuse.js', array(), '1.0', true );
			wp_enqueue_script( 'ssp-search', SIMPLY_STATIC_PRO_URL . '/assets/ssp-search.js', array( 'ssp-fuse' ), '1.0.2', true );
		}
	}

	/**
	 * Filter the Simply Static options and add pro options.
	 *
	 * @param array $options array of options.
	 * @return array
	 */
	public function add_options( $options ) {
		$ss = Simply_Static\Plugin::instance();

		$options['static-search-url'] = $ss->fetch_post_value( 'static-search-url' );

		return $options;
	}

	/**
	 * Modify task class name in Simply Static.
	 *
	 * @param string $class_name current class name.
	 * @param string $task_name current task name.
	 * @return string
	 */
	public function check_class_name( $class_name, $task_name ) {
		if ( 'search_index' === $task_name ) {
			return 'simply_static_pro\\' . ucwords( $task_name ) . '_Task';
		}
		return $class_name;
	}

	/**
	 * Create form config file with ajax or cron.
	 *
	 * @return void
	 */
	public function create_search_index() {
		$nonce = $_POST['nonce'];

		if ( ! wp_verify_nonce( $nonce, 'ssp-search-config' ) ) {
			die();
		}

		if ( ! current_user_can( 'administrator' ) ) {
			die();
		}

		if ( ! defined( 'DISABLE_WP_CRON' ) && true === apply_filters( 'ssp_search_index_with_cron', false ) || 'DISABLE_WP_CRON' !== true && true === apply_filters( 'ssp_search_index_with_cron', false ) ) {
			if ( ! wp_next_scheduled( 'ssp_search_index_cron' ) ) {
				wp_schedule_single_event( time(), 'ssp_search_index_cron' );
				$response = array( 'success' => true, 'message' => __( 'Scheduled search index creation with cron.', 'simply-static-pro' ) );
			}
		} else {
			// Cron is unavaiable.
			$results = $this->index();

			if ( is_int( $results ) ) {
				$response = array( 'success' => true, 'message' => sprintf( __( 'Created search index for %d pages/files', 'simply-static-pro' ), count( $results ) ) );
			} else {
				$response = array( 'success' => true, 'message' => __( 'There was an error creating the index file.', 'simply-static-pro' ) );
			}
		}

		print wp_json_encode( $response );
		exit;
	}

	/**
	 * Creating an index file for search.
	 *
	 * @return int
	 */
	public function index() {
		global $wp_filesystem;

		$options    = get_option( 'simply-static' );
		$dep        = apply_filters( 'ssp_search_index_depth', 10 );
		$static_url = '';

		if ( ! empty( $options['static-search-url'] ) ) {
			$static_url = untrailingslashit( $options['static-search-url'] );
		} elseif ( ! empty( $options['static-url'] ) ) {
			$static_url = untrailingslashit( $options['static-url'] );
		}

		if ( empty( $static_url ) ) {
			Simply_Static\Util::debug_log( __( 'You need to add the static URL in your search settings before you can create an index.', 'simply-static-pro' ) );
			return true;
		}

		$domain      = wp_parse_url( $static_url );
		$domain      = str_replace( '.', '-', $domain['host'] );
		$config_path = SIMPLY_STATIC_PRO_PATH . 'configs/' . $domain . '-index.json';

		// Delete old index.
		if ( file_exists( $config_path ) ) {
			wp_delete_file( $config_path, true );
		}

		$crawler = new \Arachnid\Crawler( $static_url, $dep );
		$crawler->traverse();
		$results = $crawler->getLinksArray();

		if ( isset( $results[ $static_url ]['errorInfo'] ) ) {
			Simply_Static\Util::debug_log( $results[ $static_url ]['errorInfo'] );
			return true;
		}

		// Now create the json file.
		$json = wp_json_encode( $results );

		// Initialize the WP filesystem.
		if ( empty( $wp_filesystem ) ) {
			require_once( ABSPATH . '/wp-admin/includes/file.php' );
			WP_Filesystem();
		}

		// Check if directory exists.
		$config_dir = SIMPLY_STATIC_PRO_PATH . 'configs/';

		if ( ! is_dir( $config_dir ) ) {
			wp_mkdir_p( $config_dir );
		}

		// Create and maybe commit file.
		$wp_filesystem->put_contents( $config_path, $json );

		if ( 'github' === $options['delivery_method'] ) {
			$github_file = Github_File::get_instance();
			$content     = file_get_contents( $config_path, true );

			// Try update.
			$file_updated = $github_file->update_file( 'wp-content/plugins/simply-static-pro/configs/' . $domain . '-index.json', $content, 'Updated index file', 'simply-static-pro' );

			if ( ! $file_updated ) {
				$github_file->add_file( 'wp-content/plugins/simply-static-pro/configs/' . $domain . '-index.json', $content, 'Commited index file', 'simply-static-pro' );
			}
		} else {
			if ( empty( $options['additional_files'] ) ) {
				$options['additional_files'] = $options['additional_files'] . $config_dir;
				update_option( 'simply-static', $options );
			} elseif ( strpos( $options['additional_files'], $config_dir ) === false ) {
				$options['additional_files'] = $options['additional_files'] . "\r\n" . $config_dir;
				update_option( 'simply-static', $options );
			}
		}

		if ( is_array( $results ) ) {
			return count( $results );
		}
	}
}
