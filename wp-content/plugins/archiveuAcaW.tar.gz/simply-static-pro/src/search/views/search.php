<div id='search' class='tab-pane'>
	<h2 class="title"><?php esc_html_e( 'Search', 'simply-static-pro' ); ?></h2>
	<p>
	<?php esc_html_e( 'Activate the usage of static search. It uses fuse.js and creates an complete index to search by title and content of each page.' ); ?>
	</p>
	<table class='form-table'>
		<tbody>
			<tr>
				<th>
					<label for='static-search-url'><?php esc_html_e( 'Add the URL of your static website here.', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<input type='url' id='static-search-url' name='static-search-url' value='[STATIC_URL]' class='widefat' />
					<div id='commentHelpBlock' class='help-block'>
						<p class="description"><?php _e( 'Add the URL of your static website to create a working index with correct URLs for it.', 'simply-static-pro' ); ?></p>
					</div>
				</td>
			</tr>
			<tr>
				<th>
					<label for='search-shortcode'><?php esc_html_e( 'Search Shortcode', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<code>[ssp-search]</code>
					<div id='commentHelpBlock' class='help-block'>
						<p class="description"><?php _e( 'Copy the shortcode and add it to your website. It renders a search box with autosuggestion.', 'simply-static-pro' ); ?></p>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
	<table class='form-table'>
		<tbody>
			<tr>
				<th></th>
				<td>
					<p class='submit'>
						<input class='button button-primary' type='submit' name='save' value='<?php esc_html_e( 'Save Changes', 'simply-static-pro' ); ?>' />
						[CREATE_INDEX]
						<span class="spinner"></span>
					</p>
				</td>
			</tr>
		</tbody>
	</table>
</div>
