<div id='github' class='tab-pane'>
	<h2 class="title"><?php esc_html_e( 'GitHub', 'simply-static-pro' ); ?></h2>
	<p>
	<?php
	echo sprintf(
		esc_html__( 'We use GitHub to automate the deloyment. This allows you to easily publish your static site to %s, %s, %s, %s or any other static hosting provider.', 'simply-static-pro' ),
		'<a target="_blank" href="https://patrickposner.dev/docs/simply-static/deployment/#GitHub-Pages">GitHub Pages</a>',
		'<a target="_blank" href="https://patrickposner.dev/docs/simply-static/deployment/#Cloudflare-Pages">Cloudflare Pages</a>',
		'<a target="_blank" href="https://patrickposner.dev/docs/simply-static/deployment/#AWS-S3">Amazon S3</a>',
		'<a target="_blank" href="https://patrickposner.dev/docs/simply-static/deployment/#Other-Providers">Digital Ocean Spaces</a>'
	);
	?>
	</p>
	<table class='form-table'>
		<tbody>
			<tr>
				<th>
					<label for='github-user'><?php esc_html_e( 'GitHub User', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<input type='text' id='github-user' name='github-user' value='[GITHUB_USER]' class='widefat' />
					<div id='githubHelpBlock' class='help-block'>
						<p>
						<?php echo sprintf( esc_html__( 'Enter your GitHub username. You can create an account for free %s If you are using a repository from an organization, please provide the name of the organization here.', 'simply-static-pro' ), '<a target="_blank" href="https://github.com/join">here</a>.' ); ?></p>
					</div>
				</td>
			</tr>
			<tr>
				<th>
					<label for='github-email'><?php esc_html_e( 'GitHub E-Mail', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<input type='text' id='github-email' name='github-email' value='[GITHUB_EMAIL]' class='widefat' />
					<div id='githubHelpBlock' class='help-block'>
						<p>
						<?php esc_html_e( 'Enter your GitHub email address. This will be used to commit files to your repository.', 'simply-static-pro' ); ?></p>
					</div>
				</td>
			</tr>
			<tr>
				<th>
					<label for='github-personal-access-token'><?php esc_html_e( 'Personal Access Token', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<input type='password' id='github-personal-access-token' name='github-personal-access-token' value='[GITHUB_TOKEN]' class='widefat' />
					<div id='githubHelpBlock' class='help-block'>
						<p>
						<?php echo sprintf( esc_html__( 'You need a personal access token from GitHub. Get one %s', 'simply-static-pro' ), '<a target="_blank" href="https://docs.github.com/en/github/authenticating-to-github/creating-a-personal-access-token">here</a>.' ); ?></p>
					</div>
				</td>
			</tr>
			<tr>
				<th>
					<label for='github-repository'><?php esc_html_e( 'Name your repository', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<input type='text' id='github-repository' name='github-repository' value='[GITHUB_REPOSITORY]' class='widefat' />
					<div id='githubHelpBlock' class='help-block'>
						<p><?php esc_html_e( 'Enter a name for your repository. This should be lowercase and without any spaces or special characters.', 'simply-static-pro' ); ?></p>
					</div>
				</td>
			</tr>
			<tr>
				<th>
					<label for='github-repository-visibility'><?php esc_html_e( 'Visiblity of your repository', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<select id="github-repository-visibility" name="github-repository-visibility">
						[GITHUB_VISIBILITY]
					</select>
					<div id='githubHelpBlock' class='help-block'>
						<p><?php esc_html_e( 'Decide if you want to make your repository public or private. Please check the pricing of your hoster for each option.', 'simply-static-pro' ); ?></p>
					</div>
				</td>
			</tr>
			<tr>
				<th>
					<label for='github-branch'><?php esc_html_e( 'Name your branch', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<input type='text' id='github-branch' name='github-branch' value='[GITHUB_BRANCH]' class='widefat' />
					<div id='githubHelpBlock' class='help-block'>
						<p><?php echo sprintf( esc_html__( '[OPTIONAL] add a name for your branch. Simply Static Pro automatically uses main as branch. You may want to modify that for example to %s for GitHub Pages.', 'simply-static-pro' ), '<a target="_blank" href="https://docs.github.com/en/github/working-with-github-pages/creating-a-github-pages-site">gh-pages</a>.' ); ?></p>
					</div>
				</td>
			</tr>
			<tr>
				<th>
					<label for='github-repository-link'><?php esc_html_e( 'Link to your repository', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					[GITHUB_LINK]
				</td>
			</tr>
		</tbody>
	</table>
	<table class='form-table'>
		<tbody>
			<tr>
				<th></th>
				<td>
					<p class='submit'>
						<input class='button button-primary' type='submit' name='save' value='<?php esc_html_e( 'Save Changes', 'simply-static-pro' ); ?>' />
						[GITHUB_ADD]
						[GITHUB_DELETE]
					</p>
				</td>
			</tr>
		</tbody>
	</table>
</div>
