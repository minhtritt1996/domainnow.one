<?php

namespace simply_static_pro;

use Simply_Static;

/**
 * Class to handle settings for deployment.
 */
class Comment_Settings {
	/**
	 * Contains instance or null
	 *
	 * @var object|null
	 */
	private static $instance = null;

	/**
	 * Returns instance of Comment_Settings.
	 *
	 * @return object
	 */
	public static function get_instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor for Comment_Settings.
	 */
	public function __construct() {
		add_action( 'simply_static_settings_view_tab', array( $this, 'output_settings_tab' ), 20 );
		add_action( 'simply_static_settings_view_form', array( $this, 'output_settings_form' ), 20 );
		add_filter( 'simply_static_options', array( $this, 'add_options' ) );
		add_filter( 'comment_form_defaults', array( $this, 'filter_comment_action' ) );
		add_filter( 'comment_form_default_fields', array( $this, 'filter_comment_default_fields' ) );
	}

	/**
	 * Output a new settings tab in Simply Static Settings.
	 *
	 * @return void
	 */
	public function output_settings_tab() {
		?>
		<a class='nav-tab' id='comment-tab' href='#tab-comment'><?php esc_html_e( 'Comments', 'simply-static-pro' ); ?></a>
		<?php
	}

	/**
	 * Output content for new settings tab in Simply Static Settings.
	 *
	 * @return void
	 */
	public function output_settings_form() {
		$options = get_option( 'simply-static' );

		// buffer output.
		ob_start();
		include( SIMPLY_STATIC_PRO_PATH . '/src/comment/views/comment.php' );
		$settings = ob_get_contents();
		ob_end_clean();

		// Replacing placeholders with values from options.
		if ( ! empty( $options['use-comments'] ) ) {
			if ( 'no' === $options['use-comments'] ) {
				$select_options = '<option selected value="no">no</option><option value="yes">yes</option>';
			} else {
				$select_options = '<option selected value="yes">yes</option><option value="no">no</option>';
			}
			$settings = str_replace( '[USE_COMMENTS]', $select_options, $settings );
		} else {
			$select_options = '<option value="no">no</option><option value="yes">yes</option>';
			$settings = str_replace( '[USE_COMMENTS]', $select_options, $settings );
		}

		if ( ! empty( $options['comment-endpoint'] ) ) {
			$settings = str_replace( '[COMMENT_ENDPOINT]', $options['comment-endpoint'], $settings );
		} else {
			$settings = str_replace( '[COMMENT_ENDPOINT]', '', $settings );
		}

		if ( ! empty( $options['comment-redirect'] ) ) {
			$settings = str_replace( '[COMMENT_REDIRECT]', $options['comment-redirect'], $settings );
		} else {
			$settings = str_replace( '[COMMENT_REDIRECT]', '', $settings );
		}

		echo $settings;
	}

	/**
	 * Filter the Simply Static options and add pro options.
	 *
	 * @param array $options array of options.
	 * @return array
	 */
	public function add_options( $options ) {
		$ss = Simply_Static\Plugin::instance();

		$options['use-comments']     = $ss->fetch_post_value( 'use-comments' );
		$options['comment-endpoint'] = $ss->fetch_post_value( 'comment-endpoint' );
		$options['comment-redirect'] = $ss->fetch_post_value( 'comment-redirect' );

		if ( 'yes' === $ss->fetch_post_value( 'use-comments' ) ) {
			// Modify default WordPress comments.
			$require_registration = get_option( 'comment_registration' );
			$require_name_mail    = get_option( 'require_name_email' );

			if ( 1 == $require_registration ) {
				update_option( 'comment_registration', 0 );
			}

			if ( 0 == $require_name_mail ) {
				update_option( 'comment_registration', 1 );
			}
		}
		return $options;
	}

	/**
	 * Filter comment form action.
	 *
	 * @param  array $fields list of fields for the comment form.
	 * @return array
	 */
	public function filter_comment_action( $fields ) {
		$options = get_option( 'simply-static' );

		if ( ! empty( $options['use-comments'] ) && 'yes' === $options['use-comments'] ) {
			$fields['action'] = $options['comment-endpoint'];
		}

		return $fields;
	}

	/**
	 * Filter comment form action.
	 *
	 * @param  array $fields list of fields for the comment form.
	 * @return array
	 */
	public function filter_comment_default_fields( $fields ) {
		$options = get_option( 'simply-static' );

		if ( ! empty( $options['use-comments'] ) && 'yes' === $options['use-comments'] ) {
			unset( $fields['url'] );
			unset( $fields['cookies'] );
		}

		return $fields;
	}
}
