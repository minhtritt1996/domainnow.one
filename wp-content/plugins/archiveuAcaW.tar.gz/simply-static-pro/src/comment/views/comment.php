<div id='comment' class='tab-pane'>
	<h2 class="title"><?php esc_html_e( 'Comments', 'simply-static-pro' ); ?></h2>
	<p>
	<?php esc_html_e( 'Activate the usage of static comments. It uses a webhook to send the data to the configured endpoint.' ); ?></br>
	<?php esc_html_e( 'Make sure to save your permalinks in Settings->Permalinks after saving an endpoint.' ); ?>
	</p>
	<table class='form-table'>
		<tbody>
			<tr>
				<th>
					<label for='use-comments'><?php esc_html_e( 'Use comments?', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<select id="use-comments" name="use-comments">
						[USE_COMMENTS]
					</select>
					<div id='commentsHelpBlock' class='help-block'>
						<p><?php esc_html_e( 'Decide whether or not you want to use comments on your static site.', 'simply-static-pro' ); ?></p>
					</div>
				</td>
			</tr>
			<tr>
				<th>
					<label for='comment-endpoint'><?php esc_html_e( 'Comments Endpoint', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<input type='url' id='comment-endpoint' name='comment-endpoint' value='[COMMENT_ENDPOINT]' class='widefat' />
					<div id='commentHelpBlock' class='help-block'>
						<p class="description"><?php _e( 'Add an endpoint URL from <a target="_blank" href="https://zapier.com/">Zapier</a>, <a target="_blank" href="https://ifttt.com/">IFTT</a> or use the Simply Static endpoint.', 'simply-static-pro' ); ?></p>
						<p class="description"><b><?php esc_html_e( 'Simply Static Endpoint', 'simply-static-pro' ); ?>:</b> <code><?php echo esc_url( get_bloginfo( 'url' ) ); ?>?comment</code></p>
					</div>
				</td>
			</tr>
			<tr>
				<th>
					<label for='comment-redirect'><?php esc_html_e( 'Comment Redirect', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<input type='url' id='comment-redirect' name='comment-redirect' value='[COMMENT_REDIRECT]' class='widefat' />
					<div id='commentHelpBlock' class='help-block'>
						<p class="description"><?php esc_html_e( 'Due to the fact that the page needs to be regenerated after a comment was added, you should redirect your user to a custom "thank you for your comment" page. The page will be generated and commited automatically, but it may take up to a minute.', 'simply-static-pro' ); ?></p>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
	<table class='form-table'>
		<tbody>
			<tr>
				<th></th>
				<td>
					<p class='submit'>
						<input class='button button-primary' type='submit' name='save' value='<?php esc_html_e( 'Save Changes', 'simply-static-pro' ); ?>' />
					</p>
				</td>
			</tr>
		</tbody>
	</table>
</div>
