<?php

namespace simply_static_pro;

use Simply_Static;

/**
 * Class to handle comments webhooks.
 */
class Comment_Webhook {

	/**
	 * Contains instance or null
	 *
	 * @var object|null
	 */
	private static $instance = null;

	/**
	 * Returns instance of Webhook.
	 *
	 * @return object
	 */
	public static function get_instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor for Form_Webhook.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'comment_handler' ) );
	}

	/**
	 * Handles the HTTP Request sent to your site's webhook
	 */
	public function comment_handler() {
		$options = get_option( 'simply-static' );

		if ( ! empty( $options['destination_host'] ) ) {
			// Check request first.
			$allowed_hosts = array( $options['destination_host'] );

			if ( ! isset( $_SERVER['HTTP_HOST'] ) || ! in_array( $_SERVER['HTTP_HOST'], $allowed_hosts ) ) {
				return;
			}
		}

		// Check if the webhook should be fired.
		if ( ! isset( $_GET['comment'] ) ) {
			return;
		}

		// Check if there is request.
		if ( empty( $_POST ) ) {
			return;
		}

		// If comments deactivated do nothing.
		if ( 'yes' !== $options['use-comments'] ) {
			return;
		}

		$comment = esc_html( $_POST['comment'] );
		$author  = esc_html( $_POST['author'] );
		$email   = esc_html( $_POST['email'] );
		$post_id = esc_html( $_POST['comment_post_ID'] );

		$data = array(
			'comment_post_ID'      => 1,
			'comment_author'       => $author,
			'comment_author_email' => $email,
			'comment_author_url'   => '',
			'comment_content'      => $comment,
			'comment_author_IP'    => '',
			'comment_agent'        => '',
			'comment_type'         => '',
			'comment_date'         => gmdate( 'Y-m-d H:i:s' ),
			'comment_date_gmt'     => gmdate( 'Y-m-d H:i:s' ),
			'comment_approved'     => 1,
		);

		wp_insert_comment( $data );

		do_action( 'ssp_comment_added', $post_id );

		if ( ! empty( $options['comment-redirect'] ) ) {
			wp_redirect( $options['comment-redirect'] );
			exit;
		}
	}
}

