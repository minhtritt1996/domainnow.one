<div id='form' class='tab-pane'>
	<h2 class="title"><?php esc_html_e( 'Forms', 'simply-static-pro' ); ?></h2>
	<p>
	<?php esc_html_e( 'Generate a form index file to use forms on your static website.' ); ?>
	</p>
	<table class='form-table'>
		<tbody>
			<tr>
				<th>
					<label for='use-forms'><?php esc_html_e( 'Use forms?', 'simply-static-pro' ); ?></label>
				</th>
				<td>
					<select id="use-forms" name="use-forms">
						[USE_FORMS]
					</select>
					<div id='formsHelpBlock' class='help-block'>
						<p><?php esc_html_e( 'Decide whether or not you want to use forms on your static site.', 'simply-static-pro' ); ?></p>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
	<table class='form-table'>
		<tbody>
			<tr>
				<th></th>
				<td>
					<p class='submit'>
						<input class='button button-primary' type='submit' name='save' value='<?php esc_html_e( 'Save Changes', 'simply-static-pro' ); ?>' />
						[CREATE_FORM_CONFIG]
						<span class="spinner"></span>
					</p>
				</td>
			</tr>
		</tbody>
	</table>
</div>
